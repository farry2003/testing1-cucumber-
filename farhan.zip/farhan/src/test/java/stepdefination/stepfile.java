package stepdefination;


import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;

public class stepfile {

    @Given("the following test data")
    public void the_following_test_data(DataTable dataTable) {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        for (Map<String, String> row : rows) {
            System.out.println("Username: " + row.get("username") + ", Password: " + row.get("password"));
        }
    }
}