package nbdd;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import io.cucumber.java.en.*;

public class bdd {
	


	

	public class LoginSteps {
	    WebDriver driver;

	    @Given("the user launches the browser")
	    public void launchBrowser() {
	        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
	        driver = new ChromeDriver();
	    }

	    @When("the user opens the login page")
	    public void openLoginPage() {
	        driver.get("https://example.com/login");
	    }

	    @Then("the login page should be displayed")
	    public void verifyLoginPage() {
	        String title = driver.getTitle();
	        if (!title.contains("Login")) {
	            throw new AssertionError("Login page not displayed");
	        }
	        
	      @BeforeSuite
	      public void verifyLoginPage2() {
		        String title = driver.getTitle();
		        if (!title.contains("Login")) {
		            throw new AssertionError("Login page not displayed");
		        }
	        driver.quit();
	    }
	}
}
