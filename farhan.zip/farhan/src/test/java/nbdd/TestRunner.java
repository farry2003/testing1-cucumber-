package nbdd;

import java.util.*;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources/features",
    glue = "stepDefinitions",
    tags = "@golang",
    plugin = {"pretty", "html:target/cucumber-reports"},
    momochrome ="true"
)
public class TestRunner {
	

	   public static void main(String[] args) {
	        System.out.print("gohome");
	    }

}
