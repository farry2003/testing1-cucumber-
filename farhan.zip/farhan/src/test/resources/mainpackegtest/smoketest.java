package mainpackegtest;
import 
public class smoketest {

}
