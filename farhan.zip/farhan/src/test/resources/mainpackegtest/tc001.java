package mainpackegtest;

import org.openqa.selenium.support.decorators.WebDriverDecorator;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class tc001 {
	public static void main(String[] args) throws InterruptedException {
	     WebDriver driver = new ChromeDriver();
		driver.get("https://awesomeqa.com/contact/");
		
		
		List <WebElement> el = driver.findElements(By.tagName("a"));
		
		List <String> Links1 = new ArrayList <String>();
		
		for(int i = 0 ; i<=el.size()-1;i++)
		{
			String linkname = el.get(i).getText();
			Links1.add(linkname);
			
			System.out.println(linkname);
			
			Thread.sleep(20);
			
		}
		Thread.sleep(1000);
       System.out.println(Links1);
       
       
       boolean checkVal=Links1.contains("Register");
       
       
       
       if(checkVal == true ) {
    	  System.out.println("link is present");
       }
       else {
    	   System.out.print("link is not prsent");
       }
       
       
	}
  @Test
  public void f() {
  }
}
