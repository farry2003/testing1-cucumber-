package mainpackegtest;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver; 


public class google_searchoption {
 public static void main(String[] args) throws InterruptedException{
	 WebDriver driver = new ChromeDriver();
	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3000));
	 driver.manage().window().maximize();
     driver.get("https://www.google.com/");
     driver.findElement(By.name("q")).sendKeys("alice");
     List <WebElement> elements = driver.findElements(By.xpath("//*[@id=\"Alh6id\"]/div[1]/div/ul/li"));
     int count = elements.size();
     Thread.sleep(3000);
     for(WebElement li:elements) {
    	 System.out.println(li.getText());
     }
     
//     for(int i = 0 ; i<=count;i++) {
//    	 String val = elements.get(i).getText();
//    	  System.out.println(val);
//     }
     
     
 }
}
