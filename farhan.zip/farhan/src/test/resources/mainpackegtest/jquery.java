package mainpackegtest;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class jquery {
    public static void main(String[] args) throws InterruptedException {
        WebDriver wd = new ChromeDriver();
        wd.get("http://jqueryui.com/droppable/");
        Thread.sleep(2000);

        wd.switchTo().frame(0);
        Thread.sleep(2000);

        Actions act = new Actions(wd);
        WebElement src = wd.findElement(By.id("draggable"));
        WebElement dest = wd.findElement(By.id("droppable"));
        act.clickAndHold(src).moveToElement(dest).release().build().perform();

        wd.switchTo().defaultContent();
    }
}


public static void  HandleAlert(WebDriver driver) {
   // public static void main1(String[] args) throws InterruptedException {
       // WebDriver driver = new ChromeDriver();
        driver.get("https://testpages.herokuapp.com/styled/alerts/alert-test.html");

        // Click the button that triggers the alert
        driver.findElement(By.id("alertexamples")).click();

        // Switch to the alert and read its text
        Alert alert = driver.switchTo().alert();
        System.out.println("Alert says: " + alert.getText());

        Thread.sleep(3000); // Wait to see the alert

        alert.accept(); // Close the alert
        driver.quit();
    }



public static void price_compare(WebDriver driver) 
{ 
	driver.get("https://awesomeqa.com/ui/index.php?route=common/home");
	
	driver.findElement(By.id(""))
	}